# VESPER — Financial Clarity

Aplikasi pembukuan harian untuk UMKM, jasa, dagang, dan manufaktur.
Satu basis kode, empat platform: **Android, iOS, Windows, macOS** (+ Linux & web/PWA).

Seluruh data tersimpan di perangkat (IndexedDB). Tidak ada server, tidak ada internet
yang dibutuhkan — termasuk fontnya, yang sudah tertanam di dalam berkas.

---

## Isi paket

```
vesper/
├── www/                        ← aplikasi itu sendiri
│   ├── index.html              satu berkas, offline penuh (±340 KB)
│   ├── manifest.webmanifest    identitas PWA
│   ├── sw.js                   service worker (mode web)
│   └── icons/                  ikon aplikasi semua ukuran
├── electron/                   pembungkus desktop (Windows/macOS/Linux)
│   ├── main.js
│   └── preload.js
├── resources/                  ikon 1024px & splash screen sumber
├── capacitor.config.json       konfigurasi Android/iOS
├── electron-builder.json       konfigurasi installer desktop
├── package.json
└── .github/workflows/          build otomatis di GitHub
    ├── build-android.yml       → menghasilkan .apk
    └── build-desktop.yml       → menghasilkan .exe / .dmg / .AppImage
```

---

## Cara 1 — Dapatkan .APK tanpa menginstal apa pun (paling mudah)

Kamu tidak perlu Android Studio. GitHub yang akan meng-compile-nya.

1. Buat repository baru di GitHub (boleh *private*).
2. Unggah seluruh isi folder ini ke repository tersebut
   (bisa lewat tombol **Add file → Upload files** di web GitHub).
3. Buka tab **Actions** → pilih **Build APK (Android)** → **Run workflow**.
4. Tunggu ±8–12 menit. Setelah tanda centang hijau muncul, buka halaman
   run tersebut → bagian **Artifacts** → unduh **VESPER-android**.
5. Di dalamnya ada `app-debug.apk`. Kirim ke HP Android, buka, izinkan
   *"Install dari sumber tidak dikenal"*, selesai.

> APK debug sudah bisa dipakai sendiri dan dibagikan ke teman/klien.
> Untuk masuk **Google Play**, kamu butuh versi *release* yang ditandatangani —
> lihat bagian "Tanda tangan & Play Store" di bawah.

### Versi desktop
Di tab **Actions**, jalankan **Build Desktop** → hasilnya `.exe` (Windows),
`.dmg` (macOS), dan `.AppImage`/`.deb` (Linux).

---

## Cara 2 — Build sendiri di komputer

Prasyarat: **Node.js 20+**, dan **Android Studio** (untuk Android) atau
**Xcode** (untuk iOS, wajib macOS).

```bash
npm install

# ── Android ─────────────────────────────────────────────
npx cap add android
npx @capacitor/assets generate --android \
    --iconBackgroundColor "#0F766E" --splashBackgroundColor "#0E1413"
npm run android:apk
# hasil: android/app/build/outputs/apk/debug/app-debug.apk

# ── iOS (butuh Mac + Xcode) ─────────────────────────────
npx cap add ios
npx @capacitor/assets generate --ios
npm run ios:open        # lalu tekan ▶ Run di Xcode

# ── Windows / macOS / Linux ─────────────────────────────
npm run desktop:dev     # coba dulu
npm run desktop:build   # bikin installer → dist-desktop/
```

Setiap kali `www/index.html` berubah, jalankan `npx cap sync` agar
Android dan iOS ikut diperbarui.

---

## Mencetak dan membagikan laporan

Di halaman **Laporan Keuangan** ada dua tombol:

- **Cetak** — membuka dialog cetak sistem. Keempat laporan (Laba Rugi, Ekuitas,
  Neraca, Arus Kas) ikut keluar, hitam putih, dengan kop surat berlogo.
  Di Android hasilnya bisa langsung "Simpan sebagai PDF" lalu dibagikan.
- **Bagikan** — mengirim laporan sebagai **teks** ke WhatsApp, Telegram, email,
  atau aplikasi apa pun. Tidak perlu diunduh dulu, penerima langsung membacanya
  di chat. Kalau perangkat tidak mendukung berbagi, teksnya otomatis disalin
  ke papan klip.

### Tombol "Tampilan Desktop" (hanya muncul di HP/tablet)

Di HP, tabel Buku Besar dan Jurnal harus digulir ke samping karena layarnya
sempit. Tekan **Tampilan Desktop** di menu bawah, dan aplikasi langsung memakai
tata letak desktop penuh: sidebar muncul, seluruh kolom tabel terlihat, dan
hasil cetaknya sama persis dengan cetakan dari komputer. Cubit layar untuk
memperbesar bagian yang ingin dibaca.

Tombolnya berubah jadi **Tampilan HP** untuk kembali, dan pilihan itu diingat
sampai kamu menggantinya lagi.

### Tentang tulisan `file:///…` dan tanggal di pojok kertas

Kalau kamu mencetak dari **browser**, browser sendiri menambahkan baris alamat
berkas dan tanggal di tepi atas–bawah kertas. Itu milik browser, bukan bagian
dari VESPER, dan tidak bisa dihapus dari dalam aplikasi. Dua cara menghilangkannya:

1. Di dialog cetak, buka **Setelan lainnya / More settings** → hilangkan centang
   **Header dan footer**.
2. Atau pakai versi **APK / aplikasi desktop** — di sana baris itu memang tidak
   pernah muncul, karena tidak ada address bar yang bisa dicetak.

---

## Cara 3 — Pasang sebagai aplikasi tanpa build (PWA)

`www/` sudah lengkap sebagai PWA. Unggah foldernya ke hosting statis apa pun
(GitHub Pages, Netlify, Cloudflare Pages), lalu buka di HP:

- **Android/Chrome** → menu ⋮ → *Install app*
- **iPhone/Safari** → Bagikan → *Add to Home Screen*
- **Windows/Mac/Edge/Chrome** → ikon *Install* di address bar

Hasilnya berjalan penuh layar, punya ikon sendiri, dan tetap jalan offline.
Ini cara tercepat untuk uji coba ke calon pengguna sebelum masuk toko aplikasi.

---

## Tanda tangan & Google Play

APK debug tidak bisa diunggah ke Play Store. Untuk versi release:

```bash
keytool -genkey -v -keystore vesper.keystore -alias vesper \
        -keyalg RSA -keysize 2048 -validity 10000
```

Simpan `vesper.keystore` **baik-baik** — kalau hilang, kamu tidak akan pernah
bisa memperbarui aplikasi yang sudah terbit. Lalu tambahkan 4 secret di GitHub
(*Settings → Secrets and variables → Actions*):

| Secret | Isi |
|---|---|
| `KEYSTORE_BASE64` | hasil `base64 -i vesper.keystore` (macOS/Linux) |
| `KEYSTORE_PASSWORD` | password keystore |
| `KEY_ALIAS` | `vesper` |
| `KEY_PASSWORD` | password key |

Setelah itu workflow otomatis ikut menghasilkan `.aab` yang siap diunggah ke Play Console.

Google Play juga mewajibkan **kebijakan privasi** yang bisa diakses publik.
Untuk VESPER isinya sederhana: aplikasi tidak mengumpulkan data apa pun,
semua tersimpan lokal di perangkat pengguna.

---

## Yang berubah dari versi HTML sebelumnya

| | Sebelum | Sekarang |
|---|---|---|
| Nama | Siklus Akuntansi UMKM | **VESPER — Financial Clarity** |
| Bentuk | wisaya 8 langkah berurutan | **aplikasi pembukuan harian**, buka halaman mana saja kapan saja |
| Navigasi | 8 langkah bernomor + bilah langkah di tiap halaman | Ringkasan · Pembukuan · Hasil, lalu **satu** Pengaturan |
| Input transaksi | halaman terpisah dari jurnal umum | **satu halaman Transaksi**, dengan tampilan Ringkas / Rinci |
| Neraca Saldo & Neraca Disesuaikan | dua halaman tersendiri | dihapus dari navigasi (perhitungannya tetap dipakai laporan) |
| Panduan | panduan 8 langkah, kotak tips, alert petunjuk | dihapus seluruhnya |
| Watermark cetak | "NANDA PERSPECTIVE" | **dihapus**; diganti kop surat berlogo |
| Cetak | margin seadanya | **A4 potret, margin 20mm/18mm**, kop surat korporat (logo + VESPER + kontak usaha), hitam putih kecuali logo |
| Tampilan | satu layout | adaptif: sidebar di desktop, tab bar + tombol tambah melayang di HP |
| Berbagi laporan | tidak ada | tombol **Bagikan** — kirim laporan sebagai teks ke WhatsApp dll |
| Tampilan di HP | terpaksa versi sempit | tombol **Tampilan Desktop** — tata letak & cetakan penuh dari HP |
| Laporan di layar | baris total berlatar hijau | **polos seperti di kertas** — hierarki dari garis & tebal huruf; warna hanya untuk peringatan |
| Kode Akun & Perusahaan | dua halaman terpisah | satu halaman **Pengaturan** bertab (Perusahaan · Kode Akun · Riwayat Periode) |
| Judul halaman | muncul dua kali (bilah atas + isi halaman) | **sekali saja**; bilah atas jadi bilah konteks nama usaha & periode, dan hanya di HP |
| Ekspor | tombol di menu cepat | pindah ke **Pengaturan → Perusahaan**, tempatnya bersama Cadangan |
| Lebar halaman di desktop | isi dibatasi 1240px, sisanya pita kosong | **mengisi lebar jendela** — 1 lajur di HP, 2 lajur mulai 1100px |
| Kotak konfirmasi | semua merah, semua bertuliskan "terhapus permanen", semua minta ketik HAPUS | **dua nada** — merah hanya untuk yang benar-benar menghapus; kata konfirmasi menyebut tindakannya (GANTI, HAPUS) |
| Font | diunduh dari Google Fonts | **tertanam** — offline sungguhan |
| Warna | terracotta/cream | kertas–tinta–teal, **satu aksen** untuk seluruh aplikasi (emas hanya di dalam logo) |
| Grafik | Chart.js 204 KB | **SVG buatan sendiri**, ikut tema, nol tambahan berkas |
| Angka | bilangan desimal | **bilangan bulat** — tidak ada selisih pembulatan |
| Hapus transaksi | dihapus permanen | **jurnal balik**, jejaknya tetap ada |
| Cadangan | tidak ada | 5 salinan otomatis di perangkat, bisa dipulihkan |
| Salah input | tidak diperiksa | **peringatan otomatis** (beban dikreditkan, kas minus, nominal janggal) |
| Kunci periode | tidak ada | ada, di Pengaturan |

Mesin akuntansinya **tidak disentuh** — logika debit/kredit, COA, HPP,
penyesuaian, dan laporan tetap persis sama seperti sebelumnya.
