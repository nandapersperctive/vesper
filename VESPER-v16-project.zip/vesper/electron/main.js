/* VESPER — Electron shell (Windows, macOS, Linux)
   Memuat berkas www/index.html yang sama persis dengan versi mobile. */
const { app, BrowserWindow, Menu, shell, nativeTheme, dialog } = require('electron');
const path = require('path');

const WWW = path.join(__dirname, '..', 'www', 'index.html');
let win = null;

function bg() {
  return nativeTheme.shouldUseDarkColors ? '#0A0D15' : '#F5F6FA';
}

function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 900,
    minWidth: 380,
    minHeight: 560,
    show: false,
    backgroundColor: bg(),
    title: 'VESPER — Financial Clarity',
    icon: path.join(__dirname, '..', 'resources', 'icon.png'),
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    autoHideMenuBar: process.platform !== 'darwin',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false
    }
  });

  win.loadFile(WWW);
  win.once('ready-to-show', () => win.show());

  // Semua tautan eksternal dibuka di browser, bukan di dalam aplikasi
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) { e.preventDefault(); shell.openExternal(url); }
  });

  nativeTheme.on('updated', () => win && win.setBackgroundColor(bg()));
  win.on('closed', () => { win = null; });
}

function buildMenu() {
  const isMac = process.platform === 'darwin';
  const template = [
    ...(isMac ? [{ role: 'appMenu' }] : []),
    {
      label: 'Berkas',
      submenu: [
        { label: 'Cetak / Simpan PDF…', accelerator: 'CmdOrCtrl+P',
          click: () => win && win.webContents.print({ silent: false, printBackground: true }) },
        { type: 'separator' },
        isMac ? { role: 'close', label: 'Tutup' } : { role: 'quit', label: 'Keluar' }
      ]
    },
    { label: 'Ubah', submenu: [
        { role: 'undo', label: 'Urungkan' }, { role: 'redo', label: 'Ulangi' },
        { type: 'separator' },
        { role: 'cut', label: 'Potong' }, { role: 'copy', label: 'Salin' },
        { role: 'paste', label: 'Tempel' }, { role: 'selectAll', label: 'Pilih Semua' }
      ] },
    { label: 'Tampilan', submenu: [
        { role: 'reload', label: 'Muat Ulang' },
        { role: 'resetZoom', label: 'Ukuran Normal' },
        { role: 'zoomIn', label: 'Perbesar' },
        { role: 'zoomOut', label: 'Perkecil' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Layar Penuh' }
      ] },
    { label: 'Bantuan', submenu: [
        { label: 'Tentang VESPER',
          click: () => dialog.showMessageBox(win, {
            type: 'info', title: 'Tentang VESPER',
            message: 'VESPER — Financial Clarity',
            detail: 'Versi ' + app.getVersion() +
              '\nSiklus akuntansi 8 langkah untuk UMKM, jasa, dagang & manufaktur.' +
              '\n\nSeluruh data tersimpan di perangkat ini (offline).'
          }) }
      ] }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

const single = app.requestSingleInstanceLock();
if (!single) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    buildMenu();
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
