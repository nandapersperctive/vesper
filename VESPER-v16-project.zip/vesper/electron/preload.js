/* Preload minimal — tidak membuka akses Node ke halaman.
   Hanya menandai bahwa aplikasi berjalan sebagai desktop. */
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('VESPER_DESKTOP', {
  platform: process.platform,
  version: process.versions.electron
});
