/* VESPER — service worker
   Aplikasi ini satu berkas HTML mandiri, jadi strateginya sederhana:
   simpan seluruh shell di cache, lalu sajikan dari cache lebih dulu.
   Data akuntansi TIDAK disimpan di sini — datanya ada di IndexedDB. */

const CACHE = 'vesper-v1';
const ASSETS = [
  './',
  'index.html',
  'manifest.webmanifest',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/maskable-512.png',
  'icons/icon-180.png',
  'icons/favicon.ico'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(ASSETS).catch(() => c.add('index.html')))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;

  // Navigasi → selalu kembalikan shell (SPA satu halaman)
  if (req.mode === 'navigate') {
    e.respondWith(
      caches.match('index.html').then(r => r || fetch(req).catch(() => caches.match('index.html')))
    );
    return;
  }

  // Aset → cache-first, isi cache di belakang layar
  e.respondWith(
    caches.match(req).then(cached => cached || fetch(req).then(res => {
      if (res && res.status === 200 && res.type === 'basic') {
        const copy = res.clone();
        caches.open(CACHE).then(c => c.put(req, copy));
      }
      return res;
    }).catch(() => cached))
  );
});
